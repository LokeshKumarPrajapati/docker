import Vue from 'vue'
import Glide from '@glidejs/glide'

Vue.use(Glide)
