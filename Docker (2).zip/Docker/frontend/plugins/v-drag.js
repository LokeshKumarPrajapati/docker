import Vue from 'vue'
import VDragged from 'v-dragged'

Vue.use(VDragged)
