<template>
  <div class="p-tile">
    <div
      class="img-wrapper pb-100p"
    >
      <div
        class="shimmer"
      />
    </div>
    <div
      class="h-24x shimmer mtb-10"
    />
    <div
      class="h-24x w-70 shimmer"
    />
  </div>
</template>

<script>
  export default {
    name: 'TileShimmer',
    data() {
      return {}
    },
    watch: {},
    props: {
    },
    components: {},
    computed: {},
    mixins: [],
    methods: {},
    created() {
    },
    mounted() {
    }
  }
</script>

