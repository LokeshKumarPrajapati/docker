const middleware = {}

middleware['common-middleware'] = require('..\\middleware\\common-middleware.js')
middleware['common-middleware'] = middleware['common-middleware'].default || middleware['common-middleware']

middleware['non-logged-in'] = require('..\\middleware\\non-logged-in.js')
middleware['non-logged-in'] = middleware['non-logged-in'].default || middleware['non-logged-in']

export default middleware
