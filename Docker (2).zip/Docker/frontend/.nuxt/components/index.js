export { default as AccountLayout } from '../..\\components\\AccountLayout.vue'
export { default as AddressPopup } from '../..\\components\\AddressPopup.vue'
export { default as AjaxButton } from '../..\\components\\AjaxButton.vue'
export { default as BankPopup } from '../..\\components\\BankPopup.vue'
export { default as Banner } from '../..\\components\\Banner.vue'
export { default as BrandTile } from '../..\\components\\BrandTile.vue'
export { default as Breadcrumb } from '../..\\components\\Breadcrumb.vue'
export { default as CartList } from '../..\\components\\CartList.vue'
export { default as CartProductTile } from '../..\\components\\CartProductTile.vue'
export { default as CategoryListingLayout } from '../..\\components\\CategoryListingLayout.vue'
export { default as CategoryTile } from '../..\\components\\CategoryTile.vue'
export { default as CheckoutRight } from '../..\\components\\CheckoutRight.vue'
export { default as ComparedTile } from '../..\\components\\ComparedTile.vue'
export { default as Contact } from '../..\\components\\Contact.vue'
export { default as Countdown } from '../..\\components\\Countdown.vue'
export { default as DetailRight } from '../..\\components\\DetailRight.vue'
export { default as Discover } from '../..\\components\\Discover.vue'
export { default as Dropdown } from '../..\\components\\Dropdown.vue'
export { default as ErrorHandler } from '../..\\components\\ErrorHandler.vue'
export { default as Featured } from '../..\\components\\Featured.vue'
export { default as FeaturedBrands } from '../..\\components\\FeaturedBrands.vue'
export { default as FilterBrand } from '../..\\components\\FilterBrand.vue'
export { default as FilterCategory3 } from '../..\\components\\FilterCategory-3.vue'
export { default as FilterCategory } from '../..\\components\\FilterCategory.vue'
export { default as FilterCategory2 } from '../..\\components\\FilterCategory2.vue'
export { default as FilterCollection } from '../..\\components\\FilterCollection.vue'
export { default as FilterPrice } from '../..\\components\\FilterPrice.vue'
export { default as FilterRating } from '../..\\components\\FilterRating.vue'
export { default as FilterShipping } from '../..\\components\\FilterShipping.vue'
export { default as FlashProductTile } from '../..\\components\\FlashProductTile.vue'
export { default as FlashSale } from '../..\\components\\FlashSale.vue'
export { default as FlutterwavePayBtn } from '../..\\components\\FlutterwavePayBtn.vue'
export { default as FollowBtn } from '../..\\components\\FollowBtn.vue'
export { default as FooterTreeNode } from '../..\\components\\FooterTreeNode.vue'
export { default as HomeHero } from '../..\\components\\HomeHero.vue'
export { default as ImagePopup } from '../..\\components\\ImagePopup.vue'
export { default as ImageSlider } from '../..\\components\\ImageSlider.vue'
export { default as IyzicoPayment } from '../..\\components\\IyzicoPayment.vue'
export { default as LazyArea } from '../..\\components\\LazyArea.vue'
export { default as LazyImage } from '../..\\components\\LazyImage.vue'
export { default as ListingLayout } from '../..\\components\\ListingLayout.vue'
export { default as OrderCancelPopup } from '../..\\components\\OrderCancelPopup.vue'
export { default as OrderedProduct } from '../..\\components\\OrderedProduct.vue'
export { default as OrderedStatus } from '../..\\components\\OrderedStatus.vue'
export { default as OrderTabbing } from '../..\\components\\OrderTabbing.vue'
export { default as Pagination } from '../..\\components\\Pagination.vue'
export { default as PasswordField } from '../..\\components\\PasswordField.vue'
export { default as PayButton } from '../..\\components\\PayButton.vue'
export { default as PaymentGateways } from '../..\\components\\PaymentGateways.vue'
export { default as PaymentPopup } from '../..\\components\\PaymentPopup.vue'
export { default as PopOver } from '../..\\components\\PopOver.vue'
export { default as PriceFormat } from '../..\\components\\PriceFormat.vue'
export { default as ProductBanner } from '../..\\components\\ProductBanner.vue'
export { default as ProductImages } from '../..\\components\\ProductImages.vue'
export { default as ProductList } from '../..\\components\\ProductList.vue'
export { default as ProductReview } from '../..\\components\\ProductReview.vue'
export { default as ProductsDynamic } from '../..\\components\\ProductsDynamic.vue'
export { default as ProductsSlider } from '../..\\components\\ProductsSlider.vue'
export { default as ProductTile } from '../..\\components\\ProductTile.vue'
export { default as QuantityNav } from '../..\\components\\QuantityNav.vue'
export { default as RatePopup } from '../..\\components\\RatePopup.vue'
export { default as RatingStar } from '../..\\components\\RatingStar.vue'
export { default as RazorpayPayment } from '../..\\components\\RazorpayPayment.vue'
export { default as SearchedPorductTile } from '../..\\components\\SearchedPorductTile.vue'
export { default as SearchPopup } from '../..\\components\\SearchPopup.vue'
export { default as ShippingAddressPopup } from '../..\\components\\ShippingAddressPopup.vue'
export { default as SiteFeature } from '../..\\components\\SiteFeature.vue'
export { default as Sitemap } from '../..\\components\\Sitemap.vue'
export { default as SitemapItem } from '../..\\components\\SitemapItem.vue'
export { default as SocialShare } from '../..\\components\\SocialShare.vue'
export { default as SortBy } from '../..\\components\\SortBy.vue'
export { default as Spinner } from '../..\\components\\Spinner.vue'
export { default as StaticSection } from '../..\\components\\StaticSection.vue'
export { default as StickyCartBtn } from '../..\\components\\StickyCartBtn.vue'
export { default as StoreTile } from '../..\\components\\StoreTile.vue'
export { default as StripePayment } from '../..\\components\\StripePayment.vue'
export { default as SubCategoryTile } from '../..\\components\\SubCategoryTile.vue'
export { default as Subscription } from '../..\\components\\Subscription.vue'
export { default as SuggestedAjaxSlider } from '../..\\components\\SuggestedAjaxSlider.vue'
export { default as SuggestedProducts } from '../..\\components\\SuggestedProducts.vue'
export { default as TileShimmer } from '../..\\components\\TileShimmer.vue'
export { default as ToastMessage } from '../..\\components\\ToastMessage.vue'
export { default as TreeNode } from '../..\\components\\TreeNode.vue'
export { default as UserAddress } from '../..\\components\\UserAddress.vue'
export { default as Vouchers } from '../..\\components\\Vouchers.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
