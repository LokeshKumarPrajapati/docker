import locale9ec66352 from '../..\\lang\\en.json'
import locale275327d8 from '../..\\lang\\fr.json'
import locale38517862 from '../..\\lang\\ar.json'
import locale5e24acbc from '../..\\lang\\tr.json'
import locale46c744ff from '../..\\lang\\hi.json'

export const Constants = {
  COMPONENT_OPTIONS_KEY: "nuxtI18n",
  STRATEGIES: {"PREFIX":"prefix","PREFIX_EXCEPT_DEFAULT":"prefix_except_default","PREFIX_AND_DEFAULT":"prefix_and_default","NO_PREFIX":"no_prefix"},
  REDIRECT_ON_OPTIONS: {"ALL":"all","ROOT":"root","NO_PREFIX":"no prefix"},
}
export const nuxtOptions = {
  isUniversalMode: true,
  trailingSlash: undefined,
}
export const options = {
  vueI18n: {},
  vueI18nLoader: false,
  locales: [{"code":"en","file":"en.json"},{"code":"fr","file":"fr.json"},{"code":"ar","file":"ar.json"},{"code":"tr","file":"tr.json"},{"code":"hi","file":"hi.json"}],
  defaultLocale: "en",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  defaultLocaleRouteNameSuffix: "default",
  sortRoutes: true,
  strategy: "prefix_except_default",
  lazy: false,
  langDir: "D:\\codecanyon-oCTiNDBw-ishop-multivendor-laravel-vue-ecommerce-cms\\Main\\Docker\\frontend\\lang",
  rootRedirect: null,
  detectBrowserLanguage: {"alwaysRedirect":false,"cookieCrossOrigin":false,"cookieDomain":null,"cookieKey":"i18n_redirected","cookieSecure":false,"fallbackLocale":"","redirectOn":"root","useCookie":true},
  differentDomains: false,
  baseUrl: "",
  vuex: {"moduleName":"i18n","syncRouteParams":true},
  parsePages: true,
  pages: {},
  skipSettingLocaleOnNavigate: false,
  onBeforeLanguageSwitch: () => {},
  onLanguageSwitched: () => null,
  normalizedLocales: [{"code":"en","file":"en.json"},{"code":"fr","file":"fr.json"},{"code":"ar","file":"ar.json"},{"code":"tr","file":"tr.json"},{"code":"hi","file":"hi.json"}],
  localeCodes: ["en","fr","ar","tr","hi"],
  additionalMessages: [],
}

export const localeMessages = {
  'en.json': () => Promise.resolve(locale9ec66352),
  'fr.json': () => Promise.resolve(locale275327d8),
  'ar.json': () => Promise.resolve(locale38517862),
  'tr.json': () => Promise.resolve(locale5e24acbc),
  'hi.json': () => Promise.resolve(locale46c744ff),
}
