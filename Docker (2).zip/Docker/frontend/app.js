require('@nuxt/cli').run(['start'])
