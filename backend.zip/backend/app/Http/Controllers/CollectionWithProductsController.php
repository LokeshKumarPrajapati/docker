<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CollectionWithProductsController extends Controller
{
    //
}
